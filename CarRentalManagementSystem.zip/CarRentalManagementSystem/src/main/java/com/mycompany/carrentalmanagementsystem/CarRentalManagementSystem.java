/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.carrentalmanagementsystem;

/**
 *
 * @author Dell
 */
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;

// ================= CAR CLASS =================
class Car {
    int id;
    String name;
    boolean isRented;

    Car(int id, String name) {
        this.id = id;
        this.name = name;
        this.isRented = false;
    }
}

// ================= MAIN CLASS =================
public class CarRentalManagementSystem extends JFrame {

    CardLayout layout;
    JPanel mainPanel;
    ArrayList<Car> cars = new ArrayList<>();
    int carCounter = 1;

    // Dull colors
    Color bg1 = new Color(230, 230, 235);
    Color bg2 = new Color(240, 235, 230);
    Color bg3 = new Color(235, 240, 235);
    Color btnColor = new Color(180, 190, 200);

    public CarRentalManagementSystem() {

        setTitle("Car Rental Management System");
        setSize(950, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        layout = new CardLayout();
        mainPanel = new JPanel(layout);

        mainPanel.add(welcomeScreen(), "welcome");
        mainPanel.add(addCarScreen(), "add");
        mainPanel.add(viewCarScreen(), "view");
        mainPanel.add(rentCarScreen(), "rent");
        mainPanel.add(returnCarScreen(), "return");
        mainPanel.add(searchCarScreen(), "search");
        mainPanel.add(aboutScreen(), "about");

        add(mainPanel);
        setVisible(true);
    }

    // ================= BUTTON =================
    JButton btn(String text, int x, int y) {
        JButton b = new JButton(text);
        b.setBounds(x, y, 220, 40);
        b.setBackground(btnColor);
        b.setFocusPainted(false);
        b.setFont(new Font("Arial", Font.BOLD, 14));
        return b;
    }

    // ================= WELCOME =================
    JPanel welcomeScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg1);

        JLabel title = new JLabel("Car Rental Management System");
        title.setBounds(260, 50, 450, 40);
        title.setFont(new Font("Arial", Font.BOLD, 24));

        JButton add = btn("Add Car", 360, 130);
        JButton view = btn("View Cars", 360, 180);
        JButton rent = btn("Rent Car", 360, 230);
        JButton ret = btn("Return Car", 360, 280);
        JButton search = btn("Search Car", 360, 330);
        JButton about = btn("About", 360, 380);

        add.addActionListener(e -> layout.show(mainPanel, "add"));
        view.addActionListener(e -> layout.show(mainPanel, "view"));
        rent.addActionListener(e -> layout.show(mainPanel, "rent"));
        ret.addActionListener(e -> layout.show(mainPanel, "return"));
        search.addActionListener(e -> layout.show(mainPanel, "search"));
        about.addActionListener(e -> layout.show(mainPanel, "about"));

        p.add(title);
        p.add(add);
        p.add(view);
        p.add(rent);
        p.add(ret);
        p.add(search);
        p.add(about);

        return p;
    }

    // ================= ADD CAR =================
    JPanel addCarScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg2);

        JLabel label = new JLabel("Enter Car Name:");
        label.setBounds(350, 170, 200, 30);

        JTextField field = new JTextField();
        field.setBounds(350, 200, 250, 30);

        JButton addBtn = btn("Add", 350, 250);
        JButton back = btn("Back", 350, 310);

        addBtn.addActionListener(e -> {
            if (!field.getText().isEmpty()) {
                cars.add(new Car(carCounter++, field.getText()));
                JOptionPane.showMessageDialog(this, "Car Added with ID!");
                field.setText("");
            }
        });

        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(label);
        p.add(field);
        p.add(addBtn);
        p.add(back);

        return p;
    }

    // ================= VIEW =================
    JPanel viewCarScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg3);

        JTextArea area = new JTextArea();
        area.setBounds(250, 120, 450, 300);

        JButton refresh = btn("Refresh", 360, 440);
        JButton back = btn("Back", 360, 500);

        refresh.addActionListener(e -> {
            area.setText("");
            for (Car c : cars) {
                area.append("ID: " + c.id + " | " + c.name + " | "
                        + (c.isRented ? "Rented" : "Available") + "\n");
            }
        });

        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(area);
        p.add(refresh);
        p.add(back);

        return p;
    }

    // ================= RENT WITH RECEIPT =================
    JPanel rentCarScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg2);

        JLabel l1 = new JLabel("Car ID:");
        JLabel l2 = new JLabel("Customer Name:");
        JLabel l3 = new JLabel("Days:");

        l1.setBounds(350, 120, 200, 30);
        l2.setBounds(350, 170, 200, 30);
        l3.setBounds(350, 220, 200, 30);

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField daysField = new JTextField();

        idField.setBounds(350, 150, 250, 30);
        nameField.setBounds(350, 200, 250, 30);
        daysField.setBounds(350, 250, 250, 30);

        JButton rent = btn("Generate Receipt", 350, 300);
        JButton back = btn("Back", 350, 360);

        rent.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String customer = nameField.getText();
                int days = Integer.parseInt(daysField.getText());

                for (Car c : cars) {
                    if (c.id == id && !c.isRented) {

                        c.isRented = true;

                        int pricePerDay = 2000;
                        int total = pricePerDay * days;

                        String receipt =
                                "======= RENT RECEIPT =======\n" +
                                "Customer: " + customer + "\n" +
                                "Car ID: " + c.id + "\n" +
                                "Car Name: " + c.name + "\n" +
                                "Days: " + days + "\n" +
                                "Price/Day: Rs " + pricePerDay + "\n" +
                                "Total Bill: Rs " + total + "\n" +
                                "Date: " + new Date() + "\n" +
                                "============================";

                        JTextArea area = new JTextArea(receipt);
                        area.setFont(new Font("Monospaced", Font.PLAIN, 14));

                        JOptionPane.showMessageDialog(this,
                                new JScrollPane(area),
                                "Receipt",
                                JOptionPane.INFORMATION_MESSAGE);

                        return;
                    }
                }

                JOptionPane.showMessageDialog(this, "Car not available!");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(l1); p.add(l2); p.add(l3);
        p.add(idField); p.add(nameField); p.add(daysField);
        p.add(rent); p.add(back);

        return p;
    }

    // ================= RETURN =================
    JPanel returnCarScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg3);

        JLabel label = new JLabel("Enter Car ID:");
        label.setBounds(350, 170, 200, 30);

        JTextField field = new JTextField();
        field.setBounds(350, 200, 250, 30);

        JButton ret = btn("Return", 350, 250);
        JButton back = btn("Back", 350, 310);

        ret.addActionListener(e -> {
            try {
                int id = Integer.parseInt(field.getText());

                for (Car c : cars) {
                    if (c.id == id && c.isRented) {
                        c.isRented = false;
                        JOptionPane.showMessageDialog(this, "Car Returned!");
                        return;
                    }
                }

                JOptionPane.showMessageDialog(this, "Not Found!");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(label);
        p.add(field);
        p.add(ret);
        p.add(back);

        return p;
    }

    // ================= SEARCH =================
    JPanel searchCarScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg1);

        JLabel label = new JLabel("Enter Car ID:");
        label.setBounds(350, 170, 200, 30);

        JTextField field = new JTextField();
        field.setBounds(350, 200, 250, 30);

        JButton search = btn("Search", 350, 250);
        JButton back = btn("Back", 350, 310);

        search.addActionListener(e -> {
            try {
                int id = Integer.parseInt(field.getText());

                for (Car c : cars) {
                    if (c.id == id) {
                        JOptionPane.showMessageDialog(this,
                                c.name + " is " + (c.isRented ? "Rented" : "Available"));
                        return;
                    }
                }

                JOptionPane.showMessageDialog(this, "Not Found!");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(label);
        p.add(field);
        p.add(search);
        p.add(back);

        return p;
    }

    // ================= ABOUT =================
    JPanel aboutScreen() {
        JPanel p = new JPanel(null);
        p.setBackground(bg2);

        JTextArea info = new JTextArea(
                "Car Rental Management System\n\n" +
                "Features:\n" +
                "- Add Cars\n" +
                "- Rent Cars (with Receipt)\n" +
                "- Return Cars\n" +
                "- Search Cars\n\n" +
                "Project for OOP"
        );

        info.setBounds(300, 180, 320, 200);
        info.setEditable(false);

        JButton back = btn("Back", 350, 400);
        back.addActionListener(e -> layout.show(mainPanel, "welcome"));

        p.add(info);
        p.add(back);

        return p;
    }

    // ================= MAIN =================
    public static void main(String[] args) {
        new CarRentalManagementSystem();
    }
}
